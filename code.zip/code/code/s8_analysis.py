
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold, train_test_split

from config import Config
from s3_feature_extraction import extract_all
from s7_train_evaluate import FTIEBDDNetPlus, compute_metrics

METRICS = ["accuracy", "sensitivity", "specificity", "precision", "f1_score", "mcc", "balanced_accuracy"]


def _plot(df: pd.DataFrame, x: str, title: str, xlabel: str, path: Path):
    fig, ax = plt.subplots(figsize=(7, 4.5))
    for m in METRICS:
        ax.plot(df[x], df[m], marker="o", label=m.replace("_", " "))
    ax.set_xlabel(xlabel); ax.set_ylabel("Metric value"); ax.set_title(title)
    ax.grid(alpha=0.3); ax.legend(fontsize=8, ncol=2)
    fig.tight_layout(); fig.savefig(path, dpi=200); plt.close(fig)


def _stratify(y):
    c = np.bincount(y)
    return y if c[c > 0].min() >= 2 else None


# ----------------------------------------------------------------------------- (a) k-fold
def kfold_analysis(signals, F, y, cfg: Config, k: int, out: Path) -> pd.DataFrame:
    skf = StratifiedKFold(n_splits=k, shuffle=True, random_state=cfg.seed)
    rows = []
    for fold, (tr, te) in enumerate(skf.split(signals, y), 1):
        net = FTIEBDDNetPlus(cfg).fit(signals[tr], F[tr], y[tr], epochs=cfg.analysis_epochs)
        res = compute_metrics(y[te], net.predict(signals[te], F[te]), cfg.n_classes)
        rows.append({"fold": fold, **res})
        print(f"  [k={k}] fold {fold}/{k}: acc={res['accuracy']:.4f}")
    df = pd.DataFrame(rows)
    mean = {"fold": "mean", **{m: df[m].mean() for m in METRICS}}
    std = {"fold": "std", **{m: df[m].std(ddof=0) for m in METRICS}}
    df = pd.concat([df, pd.DataFrame([mean, std])], ignore_index=True)
    df.to_csv(out / f"kfold_{k}.csv", index=False)
    _plot(df.iloc[:k].assign(fold=lambda d: d["fold"].astype(int)), "fold",
          f"{k}-fold analysis", "Fold", out / f"kfold_{k}.png")
    return df


# ----------------------------------------------------------------------------- (b) training data
def training_data_analysis(signals, F, y, cfg: Config, out: Path) -> pd.DataFrame:
    rows = []
    for p in cfg.train_percentages:
        tr, te = train_test_split(np.arange(len(y)), train_size=p / 100.0,
                                  random_state=cfg.seed, stratify=_stratify(y))
        net = FTIEBDDNetPlus(cfg).fit(signals[tr], F[tr], y[tr], epochs=cfg.analysis_epochs)
        res = compute_metrics(y[te], net.predict(signals[te], F[te]), cfg.n_classes)
        rows.append({"training_data_pct": p, **res})
        print(f"  [train {p}%] acc={res['accuracy']:.4f}")
    df = pd.DataFrame(rows)
    df.to_csv(out / "training_data_analysis.csv", index=False)
    _plot(df, "training_data_pct", "Analysis based on training data", "Training data (%)",
          out / "training_data_analysis.png")
    return df


# ----------------------------------------------------------------------------- (c) noise (Eb/N0)
def add_awgn(signals: np.ndarray, ebno_db: float, rng: np.random.Generator) -> np.ndarray:
    """Additive white Gaussian noise at a given Eb/N0 (dB).

    One real sample per symbol and unit bandwidth efficiency are assumed, so the per-record
    SNR equals Eb/N0:  sigma^2 = P_signal / 10^(EbN0/10).
    """
    p = np.mean(signals ** 2, axis=1, keepdims=True)
    sigma = np.sqrt(p / (10.0 ** (ebno_db / 10.0)))
    return (signals + sigma * rng.standard_normal(signals.shape)).astype(np.float32)


def noise_analysis(signals, F, y, cfg: Config, out: Path, n_jobs: int = 1) -> pd.DataFrame:
    tr, te = train_test_split(np.arange(len(y)), test_size=0.2, random_state=cfg.seed, stratify=_stratify(y))
    net = FTIEBDDNetPlus(cfg).fit(signals[tr], F[tr], y[tr], epochs=cfg.analysis_epochs)
    rng = np.random.default_rng(cfg.seed)
    rows = []
    for db in cfg.ebno_db:
        noisy = add_awgn(signals[te], db, rng)
        Fn = extract_all(noisy, cfg, n_jobs=n_jobs)            # features re-computed from the noisy signal
        res = compute_metrics(y[te], net.predict(noisy, Fn), cfg.n_classes)
        rows.append({"ebno_db": db, **res})
        print(f"  [Eb/N0 {db} dB] acc={res['accuracy']:.4f}")
    df = pd.DataFrame(rows)
    df.to_csv(out / "noise_analysis.csv", index=False)
    _plot(df, "ebno_db", "Noise analysis", "Eb/N0 (dB)", out / "noise_analysis.png")
    return df
