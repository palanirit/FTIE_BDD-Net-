
import numpy as np
from PIL import Image, ImageDraw
from scipy.signal import butter, sosfiltfilt

PX_PER_MV = 80.0  # calibration: image pixels per millivolt


# ----------------------------------------------------------------------------- image side
def render_ecg_image(signal: np.ndarray, height: int = 300, width: int | None = None,
                     px_per_mv: float = PX_PER_MV) -> np.ndarray:
    """Return an RGB uint8 image [H, W, 3] with a black trace on a pink grid."""
    signal = np.asarray(signal, dtype=np.float64)
    width = width or signal.size
    img = Image.new("RGB", (width, height), (255, 255, 255))
    d = ImageDraw.Draw(img)
    for x in range(0, width, 10):                      # light grid
        d.line([(x, 0), (x, height)], fill=(255, 215, 215), width=1)
    for y in range(0, height, 10):
        d.line([(0, y), (width, y)], fill=(255, 215, 215), width=1)
    xs = np.linspace(0, width - 1, signal.size)
    ys = np.clip(height / 2 - signal * px_per_mv, 1, height - 2)
    d.line(list(zip(xs.tolist(), ys.tolist())), fill=(0, 0, 0), width=2)
    return np.asarray(img)


def load_ecg_image(path: str) -> np.ndarray:
    return np.asarray(Image.open(path).convert("RGB"))


# ----------------------------------------------------------------------------- digitisation
def _otsu_threshold(gray: np.ndarray) -> float:
    hist, edges = np.histogram(gray.ravel(), bins=256, range=(0, 255))
    hist = hist.astype(np.float64)
    total = hist.sum()
    centers = (edges[:-1] + edges[1:]) / 2
    w0 = np.cumsum(hist)
    w1 = total - w0
    m0 = np.cumsum(hist * centers)
    mt = m0[-1]
    valid = (w0 > 0) & (w1 > 0)
    between = np.zeros_like(w0)
    between[valid] = (w0[valid] * w1[valid]) * ((m0[valid] / w0[valid]) - ((mt - m0[valid]) / w1[valid])) ** 2
    return float(centers[int(np.argmax(between))])


def ecg_image_to_signal(img: np.ndarray, out_len: int = 1000, fs: int = 100,
                        px_per_mv: float = PX_PER_MV, bandpass: bool = True) -> np.ndarray:
    """Digitise an ECG image into a 1-D signal (mV) of length `out_len`."""
    img = np.asarray(img)
    gray = img.astype(np.float64).mean(axis=2) if img.ndim == 3 else img.astype(np.float64)
    binary = gray < _otsu_threshold(gray)               # dark trace pixels
    h, w = binary.shape
    rows = np.arange(h)[:, None]
    count = binary.sum(axis=0)
    centre = np.where(count > 0, (binary * rows).sum(axis=0) / np.maximum(count, 1), np.nan)

    cols = np.arange(w)
    good = ~np.isnan(centre)
    if good.sum() < 2:
        raise ValueError("No ECG trace found in image.")
    centre = np.interp(cols, cols[good], centre[good])  # fill gaps

    sig = (h / 2.0 - centre) / px_per_mv                 # pixel scaling -> mV
    sig = np.interp(np.linspace(0, w - 1, out_len), cols, sig)
    sig = sig - np.median(sig)
    if bandpass:
        sos = butter(3, [0.5, min(40.0, 0.45 * fs)], btype="band", fs=fs, output="sos")
        sig = sosfiltfilt(sos, sig)
    return sig.astype(np.float32)


def _roundtrip(s: np.ndarray, fs: int, out_len: int) -> np.ndarray:
    return ecg_image_to_signal(render_ecg_image(s), out_len=out_len, fs=fs)


def signals_via_images(signals: np.ndarray, fs: int = 100, out_len: int = 1000, n_jobs: int = 1) -> np.ndarray:
    """Round-trip every record: signal -> ECG image -> digitised signal."""
    if n_jobs == 1:
        return np.stack([_roundtrip(s, fs, out_len) for s in signals])
    from joblib import Parallel, delayed
    return np.stack(Parallel(n_jobs=n_jobs)(delayed(_roundtrip)(s, fs, out_len) for s in signals))
