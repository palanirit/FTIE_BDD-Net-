
import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

from config import Config


# ----------------------------------------------------------------------------- input packing (Eq. 13)
def pack_inputs(signals: np.ndarray, feats: np.ndarray, cfg: Config) -> np.ndarray:
    """Resample signal to `resampled_len`, concatenate with the selected features, pad, reshape."""
    n = signals.shape[0]
    L = cfg.resampled_len
    xs = np.linspace(0, signals.shape[1] - 1, L)
    sig = np.stack([np.interp(xs, np.arange(signals.shape[1]), s) for s in signals])
    sig = (sig - sig.mean(axis=1, keepdims=True)) / (sig.std(axis=1, keepdims=True) + 1e-8)
    h, w = cfg.input_hw
    total = h * w
    vec = np.concatenate([sig, feats], axis=1)
    if vec.shape[1] > total:
        raise ValueError(f"Input vector ({vec.shape[1]}) larger than {h}x{w}.")
    vec = np.pad(vec, ((0, 0), (0, total - vec.shape[1])))
    return vec.reshape(n, h, w, 1).astype(np.float32)


class Standardizer:
    """Z-score for the selected features (fit on training data only)."""
    def fit(self, F):
        self.mu = F.mean(axis=0); self.sd = F.std(axis=0) + 1e-8
        return self

    def transform(self, F):
        return ((F - self.mu) / self.sd).astype(np.float32)


# ----------------------------------------------------------------------------- custom layer
@keras.utils.register_keras_serializable(package="bdd")
class AddPositionEmbedding(layers.Layer):
    """Trainable positional encoding added to the token sequence."""
    def build(self, input_shape):
        self.pos = self.add_weight(name="pos", shape=(1, input_shape[1], input_shape[2]),
                                   initializer="zeros", trainable=True)

    def call(self, x):
        return x + self.pos


# ----------------------------------------------------------------------------- model
def build_bddnet_plus(cfg: Config) -> keras.Model:
    h, w = cfg.input_hw
    f1, f2 = cfg.filters
    inp = keras.Input(shape=(h, w, 1), name="input")
    x = layers.Conv2D(f1, cfg.kernel_size, padding="same", activation="relu", name="conv2d")(inp)
    x = layers.BatchNormalization(name="bn_1")(x)
    x = layers.MaxPooling2D(cfg.pool_size, name="maxpool_1")(x)
    x = layers.Conv2D(f2, cfg.kernel_size, padding="same", activation="relu", name="conv2d_1")(x)
    x = layers.BatchNormalization(name="bn_2")(x)
    x = layers.MaxPooling2D(cfg.pool_size, name="maxpool_2")(x)

    hh, ww, cc = x.shape[1], x.shape[2], x.shape[3]
    x = layers.Reshape((hh * ww, cc), name="reshape")(x)
    x = AddPositionEmbedding(name="pos_embed")(x)

    # residual multi-head self-attention
    a = layers.LayerNormalization(epsilon=1e-6)(x)
    a = layers.MultiHeadAttention(num_heads=cfg.num_heads, key_dim=cc // cfg.num_heads,
                                  name="multihead_attention")(a, a)
    x = layers.Add()([x, a])

    # residual FFN
    f = layers.LayerNormalization(epsilon=1e-6)(x)
    f = layers.Dense(cc * 2, activation="gelu", name="ffn_dense_1")(f)
    f = layers.Dense(cc, name="ffn_dense_2")(f)
    x = layers.Add()([x, f])

    x = layers.GlobalAveragePooling1D(name="gap")(x)
    out = layers.Dense(cfg.n_classes, activation="softmax", name="dense")(x)
    model = keras.Model(inp, out, name="BDD_Net_plus")
    model.compile(optimizer=keras.optimizers.Adam(cfg.learning_rate),
                  loss="sparse_categorical_crossentropy", metrics=["accuracy"])
    return model


def split_head(model: keras.Model):
    """Return (feature_extractor up to GAP, final Dense layer) for FTIE head tuning."""
    fe = keras.Model(model.input, model.get_layer("gap").output)
    return fe, model.get_layer("dense")
