""""""
import ast
from pathlib import Path

import numpy as np
import pandas as pd

from config import Config


# ----------------------------------------------------------------------------- PTB-XL
def _superclass_labels(root: Path, cfg: Config) -> pd.DataFrame:
    db = pd.read_csv(root / "ptbxl_database.csv", index_col="ecg_id")
    db["scp_codes"] = db["scp_codes"].apply(ast.literal_eval)
    stm = pd.read_csv(root / "scp_statements.csv", index_col=0)
    stm = stm[stm["diagnostic"] == 1]

    def pick(codes: dict):
        best, best_p = None, -1.0
        for code, prob in codes.items():
            if code in stm.index:
                cls = stm.loc[code, "diagnostic_class"]
                if cls in cfg.class_names and prob > best_p:
                    best, best_p = cls, prob
        return best

    db["label_name"] = db["scp_codes"].apply(pick)
    db = db.dropna(subset=["label_name"]).copy()
    db["label"] = db["label_name"].map({n: i for i, n in enumerate(cfg.class_names)})
    return db


def load_ptbxl(cfg: Config):
    """Return (signals [N, T] float32, labels [N] int64, ecg_ids [N])."""
    import wfdb  # imported lazily so the synthetic path does not need it

    root = Path(cfg.ptbxl_dir)
    if not (root / "ptbxl_database.csv").exists():
        raise FileNotFoundError(
            f"'{root}/ptbxl_database.csv' not found. Download PTB-XL "
            "(https://physionet.org/content/ptb-xl/) or run with --synthetic."
        )
    db = _superclass_labels(root, cfg)
    if cfg.max_records and cfg.max_records < len(db):
        db = db.sample(n=cfg.max_records, random_state=cfg.seed)

    sigs, labels, ids = [], [], []
    for ecg_id, row in db.iterrows():
        try:
            sig, _ = wfdb.rdsamp(str(root / row["filename_lr"]))
        except Exception as exc:  # skip unreadable records, keep going
            print(f"[warn] could not read ecg_id={ecg_id}: {exc}")
            continue
        x = np.asarray(sig[:, cfg.lead_index], dtype=np.float32)
        if x.shape[0] < cfg.signal_len:
            x = np.pad(x, (0, cfg.signal_len - x.shape[0]))
        sigs.append(x[: cfg.signal_len])
        labels.append(int(row["label"]))
        ids.append(int(ecg_id))
    return np.stack(sigs), np.asarray(labels, dtype=np.int64), np.asarray(ids)


# ----------------------------------------------------------------------------- synthetic
def _beat_template(fs: int, hr: float, rng, cls: int):
    """One synthetic ECG cycle (sum of Gaussians for P, Q, R, S, T) with class-specific changes."""
    n = int(fs * 60.0 / hr)
    t = np.linspace(0, 1, n, endpoint=False)

    def g(c, w, a):
        return a * np.exp(-0.5 * ((t - c) / w) ** 2)

    p_amp, t_amp, st = 0.15, 0.30, 0.0
    qrs_w = 0.012
    r_amp = 1.0
    if cls == 1:      # STTC: T-wave inversion / ST shift
        t_amp, st = -0.25, -0.08
    elif cls == 2:    # CD: widened QRS, longer PR
        qrs_w = 0.028
    elif cls == 3:    # MI: pathological Q wave + ST elevation
        st = 0.12
    elif cls == 4:    # HYP: tall R wave
        r_amp = 1.8
    beat = (g(0.18, 0.025, p_amp * rng.uniform(0.8, 1.2))
            + g(0.30 if cls == 2 else 0.26, qrs_w, -0.12 * (3 if cls == 3 else 1))
            + g(0.31 if cls == 2 else 0.28, qrs_w, r_amp * rng.uniform(0.9, 1.1))
            + g(0.34 if cls == 2 else 0.30, qrs_w, -0.2)
            + g(0.55, 0.05, t_amp * rng.uniform(0.8, 1.2)))
    beat += st * ((t > 0.36) & (t < 0.50))
    return beat


def make_synthetic(cfg: Config, n: int = 600):
    rng = np.random.default_rng(cfg.seed)
    sigs, labels = [], []
    for i in range(n):
        cls = i % cfg.n_classes
        hr = rng.uniform(55, 95)
        x = np.concatenate([_beat_template(cfg.fs, hr * rng.uniform(0.97, 1.03), rng, cls)
                            for _ in range(20)])
        x = x[: cfg.signal_len]
        if x.size < cfg.signal_len:
            x = np.pad(x, (0, cfg.signal_len - x.size))
        x = x + 0.02 * rng.standard_normal(x.size)
        sigs.append(x.astype(np.float32))
        labels.append(cls)
    perm = rng.permutation(n)
    return np.stack(sigs)[perm], np.asarray(labels, dtype=np.int64)[perm], np.arange(n)[perm]


def load_data(cfg: Config):
    if cfg.use_synthetic:
        return make_synthetic(cfg)
    return load_ptbxl(cfg)
