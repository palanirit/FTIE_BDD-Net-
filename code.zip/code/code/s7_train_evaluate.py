
import numpy as np
from sklearn.metrics import confusion_matrix, matthews_corrcoef
from sklearn.model_selection import train_test_split
from tensorflow import keras

from config import Config
from s4_ensemble_ranking import EnsembleRankingSelector
from s5_bddnet_plus import Standardizer, build_bddnet_plus, pack_inputs, split_head
from s6_ftie_optimizer import FTIE


# ----------------------------------------------------------------------------- metrics (Eqs 34-36 + extras)
def compute_metrics(y_true, y_pred, n_classes: int) -> dict:
    """Macro-averaged multi-class metrics (one-vs-rest for specificity)."""
    cm = confusion_matrix(y_true, y_pred, labels=np.arange(n_classes))
    tp = np.diag(cm).astype(float)
    fp = cm.sum(axis=0) - tp
    fn = cm.sum(axis=1) - tp
    tn = cm.sum() - tp - fp - fn
    eps = 1e-12
    sens = tp / (tp + fn + eps)
    spec = tn / (tn + fp + eps)
    prec = tp / (tp + fp + eps)
    f1 = 2 * prec * sens / (prec + sens + eps)
    present = (tp + fn) > 0                      # classes that exist in y_true
    m = lambda v: float(np.mean(v[present]))
    return {
        "accuracy": float(tp.sum() / max(cm.sum(), 1)),
        "sensitivity": m(sens),
        "specificity": m(spec),
        "precision": m(prec),
        "f1_score": m(f1),
        "mcc": float(matthews_corrcoef(y_true, y_pred)),
        "balanced_accuracy": float((m(sens) + m(spec)) / 2.0),
    }


# ----------------------------------------------------------------------------- full model wrapper
class FTIEBDDNetPlus:
    """signals + raw features -> ensemble ranking -> BDD-Net+ (Adam) -> FTIE head tuning."""

    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.selector = EnsembleRankingSelector(cfg.n_selected, cfg.n_bootstrap, cfg.seed)
        self.scaler = Standardizer()
        self.model: keras.Model | None = None
        self.ftie_history: list[float] = []
        self.train_history: dict = {}

    def _inputs(self, signals, F, fit=False, y=None):
        if fit:
            Fs = self.selector.fit(F, y).transform(F)
            self.scaler.fit(Fs)
        else:
            Fs = self.selector.transform(F)
        return pack_inputs(signals, self.scaler.transform(Fs), self.cfg)

    def fit(self, signals, F, y, epochs: int | None = None, use_ftie: bool = True, verbose: int = 0):
        cfg = self.cfg
        epochs = cfg.epochs if epochs is None else epochs
        keras.utils.set_random_seed(cfg.seed)
        X = self._inputs(signals, F, fit=True, y=y)

        idx = np.arange(len(y))
        strat = y if np.min(np.bincount(y)[np.bincount(y) > 0]) >= 2 else None
        tr, va = train_test_split(idx, test_size=0.1, random_state=cfg.seed, stratify=strat)

        self.model = build_bddnet_plus(cfg)
        cb = [keras.callbacks.EarlyStopping(monitor="val_loss", patience=10, restore_best_weights=True)]
        hist = self.model.fit(X[tr], y[tr], validation_data=(X[va], y[va]), epochs=epochs,
                              batch_size=cfg.batch_size, callbacks=cb, verbose=verbose)
        self.train_history = hist.history

        if use_ftie:
            self._ftie_tune(X[tr], y[tr])
        return self

    # ---- FTIE training of the classification head (fitness = Eq. 17, MSE target vs. output)
    def _ftie_tune(self, X, y):
        cfg = self.cfg
        fe, head = split_head(self.model)
        Z = fe.predict(X, batch_size=256, verbose=0).astype(np.float64)       # [N, 64]
        W, b = head.get_weights()
        w0 = np.concatenate([W.ravel(), b.ravel()])
        onehot = np.eye(cfg.n_classes)[y]
        d_in, n_cls = W.shape

        def fitness(v: np.ndarray) -> float:
            logits = Z @ v[: d_in * n_cls].reshape(d_in, n_cls) + v[d_in * n_cls:]
            logits -= logits.max(axis=1, keepdims=True)
            p = np.exp(logits); p /= p.sum(axis=1, keepdims=True)
            return float(np.mean((onehot - p) ** 2))

        spread = 0.3
        opt = FTIE(fitness, dim=w0.size, lower=w0 - spread, upper=w0 + spread,
                   population=cfg.ftie_population, iterations=cfg.ftie_iterations,
                   tribes=cfg.ftie_tribes, mutation=cfg.ftie_mutation, h=cfg.ftie_h,
                   init=w0, seed=cfg.seed)
        best, _, self.ftie_history = opt.run()
        head.set_weights([best[: d_in * n_cls].reshape(d_in, n_cls).astype(np.float32),
                          best[d_in * n_cls:].astype(np.float32)])

    def predict_proba(self, signals, F):
        return self.model.predict(self._inputs(signals, F), batch_size=256, verbose=0)

    def predict(self, signals, F):
        return np.argmax(self.predict_proba(signals, F), axis=1)
