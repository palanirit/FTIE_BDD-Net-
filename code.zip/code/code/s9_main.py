
import argparse
import json
import os
import time

os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import train_test_split

from config import Config
from s1_data_loader import load_data, make_synthetic
from s2_ecg_image_to_signal import signals_via_images
from s3_feature_extraction import extract_all, feature_names
from s7_train_evaluate import FTIEBDDNetPlus, compute_metrics
from s8_analysis import kfold_analysis, noise_analysis, training_data_analysis


def parse_args():
    ap = argparse.ArgumentParser(description="FTIE_BDD-Net+ pipeline (PTB-XL ECG)")
    ap.add_argument("--ptbxl_dir", default="ptb-xl")
    ap.add_argument("--synthetic", action="store_true", help="use synthetic ECG (no dataset needed)")
    ap.add_argument("--n_synth", type=int, default=600)
    ap.add_argument("--no_images", action="store_true", help="skip the image->signal stage")
    ap.add_argument("--max_records", type=int, default=0)
    ap.add_argument("--epochs", type=int, default=100)
    ap.add_argument("--analysis_epochs", type=int, default=10)
    ap.add_argument("--skip_analysis", action="store_true")
    ap.add_argument("--quick", action="store_true", help="2-fold only, fewer sweep points (testing)")
    ap.add_argument("--n_jobs", type=int, default=1, help="-1 = all cores for image/feature extraction")
    ap.add_argument("--out_dir", default="outputs")
    return ap.parse_args()


def plot_fig3(signals_raw, signals_feat, y_true, y_pred, cfg, path):
    """Fig. 3 style: input signal / feature-extracted signal / detected class for 2 records."""
    normal = np.where(y_true == 0)[0]
    abnormal = np.where(y_true != 0)[0]
    picks = [normal[0] if normal.size else 0, abnormal[0] if abnormal.size else 1]
    fig, ax = plt.subplots(3, 2, figsize=(10, 7))
    t = np.arange(signals_raw.shape[1]) / cfg.fs
    for c, i in enumerate(picks):
        ax[0, c].plot(t, signals_raw[i], lw=0.8); ax[0, c].set_title(f"(a/b) Input signal-{c + 1}")
        ax[1, c].plot(t, signals_feat[i], lw=0.8, color="tab:green"); ax[1, c].set_title(f"Digitised / feature signal-{c + 1}")
        ax[2, c].plot(t, signals_feat[i], lw=0.8, color="tab:red")
        ax[2, c].set_title(f"Detected signal-{c + 1}: {cfg.class_names[y_pred[i]]} (true {cfg.class_names[y_true[i]]})")
        ax[2, c].set_xlabel("Time (s)")
    fig.tight_layout(); fig.savefig(path, dpi=200); plt.close(fig)


def main():
    args = parse_args()
    cfg = Config(ptbxl_dir=args.ptbxl_dir, use_synthetic=args.synthetic, use_images=not args.no_images,
                 max_records=args.max_records, epochs=args.epochs, analysis_epochs=args.analysis_epochs,
                 out_dir=args.out_dir)
    if args.quick:
        cfg.k_folds = (2,)
        cfg.train_percentages = (50, 80)
        cfg.ebno_db = (0, 10, 30)
    out = cfg.make_out()
    t0 = time.time()

    # ---- stage 1: data
    print("[1/8] loading data ...")
    if cfg.use_synthetic:
        raw, y, ids = make_synthetic(cfg, args.n_synth)
    else:
        raw, y, ids = load_data(cfg)
    print(f"      {raw.shape[0]} records, class counts = {np.bincount(y, minlength=cfg.n_classes).tolist()}")

    # ---- stage 2: ECG image -> signal
    if cfg.use_images:
        print("[2/8] ECG image -> ECG signal ...")
        sig = signals_via_images(raw, cfg.fs, cfg.signal_len, n_jobs=args.n_jobs)
    else:
        print("[2/8] skipped (using the signal directly)")
        sig = raw.astype(np.float32)

    # ---- stage 3: features
    print("[3/8] feature extraction ...")
    F = extract_all(sig, cfg, n_jobs=args.n_jobs)
    np.savez_compressed(out / "features.npz", F=F, y=y, ids=ids, names=np.array(feature_names(cfg)))
    print(f"      feature matrix {F.shape}")

    # ---- stages 4-7: split, select, train, evaluate
    print("[4-7/8] ensemble ranking, BDD-Net+ training, FTIE tuning ...")
    strat = y if np.bincount(y)[np.bincount(y) > 0].min() >= 2 else None
    tr, te = train_test_split(np.arange(len(y)), test_size=0.2, random_state=cfg.seed, stratify=strat)
    net = FTIEBDDNetPlus(cfg).fit(sig[tr], F[tr], y[tr], epochs=cfg.epochs, use_ftie=True, verbose=1)
    pred = net.predict(sig[te], F[te])
    metrics = compute_metrics(y[te], pred, cfg.n_classes)
    print("      test metrics:", json.dumps({k: round(v, 4) for k, v in metrics.items()}))

    sel = [feature_names(cfg)[i] for i in net.selector.selected_idx_]
    (out / "selected_features.txt").write_text("\n".join(sel))
    pd.DataFrame([metrics]).to_csv(out / "test_metrics.csv", index=False)
    cm = confusion_matrix(y[te], pred, labels=np.arange(cfg.n_classes))
    pd.DataFrame(cm, index=cfg.class_names, columns=cfg.class_names).to_csv(out / "confusion_matrix.csv")
    pd.DataFrame({"iteration": range(len(net.ftie_history)), "best_fitness": net.ftie_history}
                 ).to_csv(out / "ftie_convergence.csv", index=False)
    net.model.save(out / "bddnet_plus.keras")
    plot_fig3(raw[te], sig[te], y[te], pred, cfg, out / "fig3_experimental_outcomes.png")

    # ---- stage 8: analyses
    if not args.skip_analysis:
        print("[8/8] analyses ...")
        for k in cfg.k_folds:
            kfold_analysis(sig, F, y, cfg, k, out)
        training_data_analysis(sig, F, y, cfg, out)
        noise_analysis(sig, F, y, cfg, out, n_jobs=args.n_jobs)
    print(f"done in {time.time() - t0:.1f}s -> results in '{out}/'")


if __name__ == "__main__":
    main()
