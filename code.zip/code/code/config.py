
from dataclasses import dataclass
from pathlib import Path


@dataclass
class Config:
    # ---------------- data ----------------
    ptbxl_dir: str = "ptb-xl"          # folder with ptbxl_database.csv, scp_statements.csv, records100/
    use_synthetic: bool = False        # True -> synthetic ECG (smoke tests, no download needed)
    use_images: bool = True            # True -> signal -> ECG image -> digitised signal (Section 3.2)
    lead_index: int = 1                # lead II
    fs: int = 100                      # PTB-XL 100 Hz version (10 s -> 1000 samples)
    signal_len: int = 1000
    max_records: int = 0               # 0 = all records; >0 = random subset (quick runs)
    class_names: tuple = ("NORM", "STTC", "CD", "MI", "HYP")
    n_classes: int = 5

    # ---------------- features / selection ----------------
    n_selected: int = 30               # "overall selected features ... is 30"
    n_bootstrap: int = 10              # bootstrap rankers in ensemble ranking
    lpc_order: int = 10
    swt_level: int = 3
    swt_wavelet: str = "db4"
    svd_segments: int = 10
    svd_top_k: int = 5

    # ---------------- BDD-Net+ (Table 1) ----------------
    filters: tuple = (32, 64)
    kernel_size: tuple = (3, 3)
    pool_size: tuple = (2, 2)
    num_heads: int = 4
    learning_rate: float = 0.01
    batch_size: int = 32
    epochs: int = 100
    input_hw: tuple = (33, 32)         # (signal_len=1024 + n_selected=30 -> 1054 -> padded 1056 = 33x32)
    resampled_len: int = 1024

    # ---------------- FTIE (Table 2) ----------------
    ftie_population: int = 10
    ftie_iterations: int = 10
    ftie_tribes: int = 2
    ftie_mutation: float = 0.01
    ftie_h: float = 0.5                # fractional order alpha (h)

    # ---------------- analysis ----------------
    k_folds: tuple = (5, 10)
    train_percentages: tuple = (40, 50, 60, 70, 80, 90)
    ebno_db: tuple = (0, 5, 10, 15, 20, 25, 30)
    analysis_epochs: int = 10          # epochs used inside the (many) analysis runs

    seed: int = 42
    out_dir: str = "outputs"

    def make_out(self) -> Path:
        p = Path(self.out_dir)
        p.mkdir(parents=True, exist_ok=True)
        return p
