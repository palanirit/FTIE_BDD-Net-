
import numpy as np
import pywt
from scipy.linalg import solve_toeplitz
from scipy.signal import find_peaks
from scipy.stats import kurtosis, skew

from config import Config


def _safe_stats(v: np.ndarray):
    v = np.asarray(v, dtype=np.float64)
    if v.size == 0:
        return 0.0, 0.0
    return float(np.mean(v)), float(np.std(v))


def _entropy(x: np.ndarray, bins: int = 32) -> float:
    h, _ = np.histogram(x, bins=bins)
    p = h / max(h.sum(), 1)
    p = p[p > 0]
    return float(-(p * np.log2(p)).sum())


# ----------------------------------------------------------------------------- clinical (Eqs 2-6)
def clinical_features(x: np.ndarray, fs: int) -> np.ndarray:
    """Mean and std of PP, QT, PR, RR intervals (s) and R-peak amplitude -> 10 values."""
    x = np.asarray(x, dtype=np.float64)
    thr = max(0.4 * np.max(np.abs(x)), 1e-6)
    r, _ = find_peaks(x, height=thr, distance=max(int(0.3 * fs), 1))
    if r.size < 3:                       # fall back: relaxed threshold
        r, _ = find_peaks(x, distance=max(int(0.3 * fs), 1), prominence=0.2 * np.ptp(x) + 1e-9)

    p_idx, q_idx, t_idx = [], [], []
    for i, rp in enumerate(r):
        prev_r = r[i - 1] if i > 0 else max(rp - int(0.8 * fs), 0)
        next_r = r[i + 1] if i + 1 < r.size else min(rp + int(0.8 * fs), x.size - 1)
        # Q: local min shortly before R; P: local max before Q; T: local max after R
        a, b = max(rp - int(0.06 * fs), prev_r), rp
        if b - a >= 2:
            q = a + int(np.argmin(x[a:b])); q_idx.append(q)
            a2, b2 = max(q - int(0.20 * fs), prev_r), q
            if b2 - a2 >= 2:
                p_idx.append(a2 + int(np.argmax(x[a2:b2])))
        a, b = rp + int(0.10 * fs), min(rp + int(0.45 * fs), next_r)
        if b - a >= 2:
            t_idx.append(a + int(np.argmax(x[a:b])))

    rr = np.diff(r) / fs
    pp = np.diff(p_idx) / fs if len(p_idx) > 1 else np.array([])
    n = min(len(q_idx), len(t_idx))
    qt = (np.asarray(t_idx[:n]) - np.asarray(q_idx[:n])) / fs if n else np.array([])
    m = min(len(p_idx), len(q_idx))
    pr = (np.asarray(q_idx[:m]) - np.asarray(p_idx[:m])) / fs if m else np.array([])
    r_amp = x[r] if r.size else np.array([])

    out = []
    for v in (pp, qt, pr, rr, r_amp):
        out.extend(_safe_stats(v))
    return np.asarray(out, dtype=np.float32)


# ----------------------------------------------------------------------------- SWT (Eq. 7)
def swt_features(x: np.ndarray, wavelet: str, level: int) -> np.ndarray:
    """Per band (cA_L, cD_L ... cD_1): mean |c|, std, energy, entropy -> 4*(level+1) values."""
    x = np.asarray(x, dtype=np.float64)
    mult = 2 ** level
    pad = (-x.size) % mult
    xp = np.pad(x, (0, pad), mode="edge") if pad else x
    coeffs = pywt.swt(xp, wavelet, level=level)       # list of (cA, cD), coarsest first
    bands = [coeffs[0][0]] + [cd for _, cd in coeffs]
    out = []
    for c in bands:
        out += [np.mean(np.abs(c)), np.std(c), np.log1p(np.sum(c ** 2)), _entropy(c)]
    return np.asarray(out, dtype=np.float32)


# ----------------------------------------------------------------------------- LPC (Eq. 8)
def lpc_features(x: np.ndarray, order: int) -> np.ndarray:
    x = np.asarray(x, dtype=np.float64)
    x = x - x.mean()
    ac = np.correlate(x, x, mode="full")[x.size - 1: x.size + order]
    if ac[0] <= 1e-12:
        return np.zeros(order, dtype=np.float32)
    ac[0] *= 1.0 + 1e-9                                # tiny regularisation
    try:
        a = solve_toeplitz(ac[:order], ac[1: order + 1])
    except np.linalg.LinAlgError:
        a = np.zeros(order)
    return a.astype(np.float32)


# ----------------------------------------------------------------------------- SVD (Eq. 9)
def svd_features(x: np.ndarray, segments: int, top_k: int) -> np.ndarray:
    """Re-organise the signal as a [segments, L] matrix and keep the top-k singular values."""
    x = np.asarray(x, dtype=np.float64)
    L = x.size // segments
    M = x[: L * segments].reshape(segments, L)
    s = np.linalg.svd(M, compute_uv=False)
    s = s / (s.sum() + 1e-12)                          # normalised singular spectrum
    out = np.zeros(top_k)
    out[: min(top_k, s.size)] = s[:top_k]
    return out.astype(np.float32)


# ----------------------------------------------------------------------------- CKD (Eq. 10)
def ckd_features(x: np.ndarray, fs: int) -> np.ndarray:
    """Cone-shaped kernel response: signal convolved with a cone kernel (lateral inhibition).

    K(t) = 1 - |t|/T inside |t| < T (excitatory cone) minus a wider cone (inhibitory surround).
    Returns 7 statistics of the response.
    """
    x = np.asarray(x, dtype=np.float64)
    T1, T2 = max(int(0.04 * fs), 2), max(int(0.12 * fs), 4)
    t1 = np.arange(-T1, T1 + 1); k1 = 1 - np.abs(t1) / (T1 + 1); k1 /= k1.sum()
    t2 = np.arange(-T2, T2 + 1); k2 = 1 - np.abs(t2) / (T2 + 1); k2 /= k2.sum()
    y = np.convolve(x, k1, mode="same") - np.convolve(x, k2, mode="same")
    return np.asarray([y.mean(), y.std(), np.abs(y).max(), np.log1p(np.sum(y ** 2)),
                       _entropy(y), skew(y), kurtosis(y)], dtype=np.float32)


# ----------------------------------------------------------------------------- driver (Eq. 11)
def extract_features(x: np.ndarray, cfg: Config) -> np.ndarray:
    f = np.concatenate([
        clinical_features(x, cfg.fs),
        swt_features(x, cfg.swt_wavelet, cfg.swt_level),
        lpc_features(x, cfg.lpc_order),
        svd_features(x, cfg.svd_segments, cfg.svd_top_k),
        ckd_features(x, cfg.fs),
    ])
    return np.nan_to_num(f, nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32)


def extract_all(signals: np.ndarray, cfg: Config, n_jobs: int = 1) -> np.ndarray:
    if n_jobs == 1:
        return np.stack([extract_features(s, cfg) for s in signals])
    from joblib import Parallel, delayed
    return np.stack(Parallel(n_jobs=n_jobs)(delayed(extract_features)(s, cfg) for s in signals))


def feature_names(cfg: Config):
    names = [f"{n}_{s}" for n in ("PP", "QT", "PR", "RR", "Rpeak") for s in ("mean", "std")]
    bands = [f"cA{cfg.swt_level}"] + [f"cD{l}" for l in range(cfg.swt_level, 0, -1)]
    names += [f"SWT_{b}_{s}" for b in bands for s in ("meanabs", "std", "energy", "entropy")]
    names += [f"LPC_{i + 1}" for i in range(cfg.lpc_order)]
    names += [f"SVD_{i + 1}" for i in range(cfg.svd_top_k)]
    names += [f"CKD_{s}" for s in ("mean", "std", "maxabs", "energy", "entropy", "skew", "kurt")]
    return names
