
import numpy as np
from sklearn.feature_selection import f_classif


class EnsembleRankingSelector:
    def __init__(self, n_selected: int = 30, n_bootstrap: int = 10, seed: int = 42):
        self.n_selected = n_selected
        self.n_bootstrap = n_bootstrap
        self.seed = seed
        self.selected_idx_: np.ndarray | None = None
        self.total_score_: np.ndarray | None = None

    def fit(self, X: np.ndarray, y: np.ndarray):
        rng = np.random.default_rng(self.seed)
        n, d = X.shape
        ranks = np.zeros((self.n_bootstrap, d))
        for b in range(self.n_bootstrap):
            idx = rng.integers(0, n, size=n)
            Xb, yb = X[idx], y[idx]
            if np.unique(yb).size < 2:
                continue
            with np.errstate(all="ignore"):
                score, _ = f_classif(Xb, yb)
            score = np.nan_to_num(score, nan=0.0, posinf=1e12)
            order = np.argsort(-score)                    # best feature first
            r = np.empty(d); r[order] = np.arange(1, d + 1)
            ranks[b] = r
        self.total_score_ = ranks.mean(axis=0)            # aggregation = mean rank (lower = better)
        k = min(self.n_selected, d)
        self.selected_idx_ = np.argsort(self.total_score_)[:k]
        return self

    def transform(self, X: np.ndarray) -> np.ndarray:
        if self.selected_idx_ is None:
            raise RuntimeError("Call fit() first.")
        return X[:, self.selected_idx_]

    def fit_transform(self, X, y):
        return self.fit(X, y).transform(X)
