
from typing import Callable

import numpy as np


class FTIE:
    N_ACTIONS = 3  # 0 autonomy, 1 diplomacy, 2 war

    def __init__(self, fitness_fn: Callable[[np.ndarray], float], dim: int,
                 lower: np.ndarray | float, upper: np.ndarray | float,
                 population: int = 10, iterations: int = 10, tribes: int = 2,
                 mutation: float = 0.01, h: float = 0.5, epsilon: float = 0.2,
                 q_lr: float = 0.1, q_gamma: float = 0.9, init: np.ndarray | None = None,
                 seed: int = 42):
        if population < tribes:
            raise ValueError("population must be >= tribes")
        self.f = fitness_fn
        self.dim, self.P, self.T, self.iters = dim, population, tribes, iterations
        self.lo = np.broadcast_to(np.asarray(lower, dtype=np.float64), (dim,)).copy()
        self.hi = np.broadcast_to(np.asarray(upper, dtype=np.float64), (dim,)).copy()
        self.alpha = float(h)
        self.sigma = mutation * (self.hi - self.lo)
        self.eps, self.q_lr, self.q_gamma = epsilon, q_lr, q_gamma
        self.rng = np.random.default_rng(seed)
        self.init = init
        self.history: list[float] = []

    # ------------------------------------------------------------------ helpers
    def _clip(self, x):
        return np.clip(x, self.lo, self.hi)

    def _init_population(self):
        X = self.lo + self.rng.random((self.P, self.dim)) * (self.hi - self.lo)   # Eq. (19)
        if self.init is not None:
            X[0] = self._clip(np.asarray(self.init, dtype=np.float64))            # keep the trained solution
        return X

    # ------------------------------------------------------------------ main loop
    def run(self):
        X = self._init_population()
        fit = np.array([self.f(x) for x in X])
        tribe = np.arange(self.P) % self.T
        members = [np.where(tribe == k)[0] for k in range(self.T)]
        d1 = np.zeros_like(X)      # d_t
        d2 = np.zeros_like(X)      # d_(t-1)
        Q = np.zeros((self.T, 2, self.N_ACTIONS))
        state = np.zeros(self.T, dtype=int)
        self.history = [float(fit.min())]

        for _ in range(self.iters):
            leaders = [m[np.argmin(fit[m])] for m in members]
            avg_fit = [fit[m].mean() for m in members]
            best_before = [fit[m].min() for m in members]
            actions = np.zeros(self.T, dtype=int)

            for k in range(self.T):
                if self.rng.random() < self.eps:
                    a = int(self.rng.integers(self.N_ACTIONS))
                else:
                    a = int(np.argmax(Q[k, state[k]]))
                actions[k] = a
                other = k if self.T == 1 else int(self.rng.choice([j for j in range(self.T) if j != k]))
                idx = members[k]
                lead = X[leaders[k]]
                cand = np.empty((idx.size, self.dim))

                for n, i in enumerate(idx):
                    r = self.rng.random(self.dim)
                    if a == 0:      # autonomy + fractional calculus  (Eq. 30)
                        step = (self.alpha * d1[i] + 0.5 * self.alpha * (1 - self.alpha) * d2[i]
                                + r * (lead - X[i]) + self.sigma * self.rng.standard_normal(self.dim))
                        cand[n] = X[i] + step
                    elif a == 1:    # diplomacy (Eqs. 31-32): weaker members follow the other tribe's leader more
                        span = fit[idx].max() - fit[idx].min()
                        infl = 0.0 if span <= 1e-15 else (fit[i] - fit[idx].min()) / span
                        cand[n] = X[i] + infl * r * (X[leaders[other]] - X[i])
                    else:           # war (Eq. 33)
                        winner_lead = lead if avg_fit[k] <= avg_fit[other] else X[leaders[other]]
                        if avg_fit[k] <= avg_fit[other]:   # winner consolidates
                            cand[n] = X[i] + r * (lead - X[i]) + self.sigma * self.rng.standard_normal(self.dim)
                        else:                              # captive: parameters ~ N(winner leader, var)
                            scale = 0.5 * np.abs(X[i] - winner_lead) + self.sigma
                            cand[n] = winner_lead + scale * self.rng.standard_normal(self.dim)

                cand = self._clip(cand)
                for n, i in enumerate(idx):
                    fc = self.f(cand[n])
                    if fc < fit[i]:                          # greedy acceptance
                        d2[i], d1[i] = d1[i], cand[n] - X[i]
                        X[i], fit[i] = cand[n], fc

            # reward + Q-table update, leader re-selection
            for k in range(self.T):
                best_after = fit[members[k]].min()
                reward = max(0.0, (best_before[k] - best_after) / (abs(best_before[k]) + 1e-12))
                s_next = 1 if reward > 0 else 0
                a = actions[k]
                Q[k, state[k], a] += self.q_lr * (reward + self.q_gamma * Q[k, s_next].max() - Q[k, state[k], a])
                state[k] = s_next
            self.history.append(float(fit.min()))

        best = int(np.argmin(fit))
        return X[best].copy(), float(fit[best]), list(self.history)
