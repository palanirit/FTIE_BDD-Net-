1. HARDWARE REQUIREMENTS
	OS-Windows 11
	RAM-8GB
	ROM-More than 100 GB
	GPU-yes
	CPU-1.7 GHz

2. SOFTWARE REQUIREMENTS
	Software name(Python): Version: 3.11
	(Download link: https://www.python.org/downloads/release/python-311/)
		Click -> Windows installer (64-bit).
Software name: PyCharm: Version: 2020.3.3
	(Download link: https://www.jetbrains.com/pycharm/download/other.html)
3. HOW TO RUN
Step 1: Loading the project in PYCHARM
	Open pycharm
	Go to File, select Open browse the project from your drive and select it. So that the project will get loaded into the Pycharm.
	For the first time, Pycharm will take some time to load the settings.
	Please wait if any process is loading on the bottom of the screen.
	Check the Project Interpreter 
If this location “(C:\Users\---\AppData\Local\Programs\Python\Python311-64\python.exe) is not presented, then add this ‘python.exe’ from the installed location.
	In Pycharm Terminal(bottom left), type the comment “pip install -r requirements.txt”


############

├── config.py                 # Global configuration settings, file paths, and hyperparameter setups
├── s1_data_loader.py         # Handles dataset ingestion (e.g., PTB-XL database records and metadata)
├── s2_ecg_image_to_signal.py # Handles signal conversion, format parsing, and noise filtering
├── s3_feature_extraction.py  # Comprehensive feature extractor (Clinical intervals + Transform/Advanced features)
├── s5_bddnet_plus.py         # Proposed deep learning network architecture (BDDNet+)
├── s6_ftie_optimizer.py      # Proposed optimization algorithm for hyperparameter tuning
├── s7_train_evaluate.py      # Training loop implementation and model evaluation metrics handling
├── s8_analysis.py            # Generates evaluation reports, performance metrics, and visualization curves
└── s9_main.py                # Main orchestration script combining the entire end-to-end pipeline